#main_controller.py for hand movement
#heatmapV2.py for tactile visualization in old topic: "/TactileMeasurements"
#heatmapV2_wenbin.py for tactile visualization in new topic: "/tactile_states"
