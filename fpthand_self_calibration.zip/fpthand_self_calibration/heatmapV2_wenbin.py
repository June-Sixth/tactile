#!/usr/bin/env python3  

from trx_tactile_msgs.msg import TrxTactileStates
import rospy
from datetime import datetime
from socket import *
import matplotlib as mpl
mpl.use('TkAgg')  # or whatever other backend that you want
import matplotlib.pyplot as plt
from matplotlib import animation
import numpy as np
import pathlib
import threading
import seaborn as sns


# plt.rcParams["figure.figsize"] = [30, 40]
plt.rcParams["figure.autolayout"] = True

this_file_dir = str(pathlib.Path(__file__).parent.absolute())
print("This file dir:", this_file_dir)


class TacDataClass():
    def __init__(self):
        self.data = np.empty(640)
        self.threshold = 50
        self.part_f0dip = np.ones([12, 12]) * -100
        self.part_f1dip = np.ones([12, 12]) * -100
        self.part_f2dip = np.ones([12, 12]) * -100
        

class TacPlotClass_dip():    
    def __init__(self, dataClass):
        self._dataClass = dataClass
        self.fig = plt.figure(figsize=(30, 20))
        plt.subplot(231)
        plt.title("dip0", fontsize = 25)    
        sns.heatmap(self._dataClass.part_f1dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(233)
        plt.title("dip1", fontsize = 25)
        sns.heatmap(self._dataClass.part_f2dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(235)
        plt.title("dip2", fontsize = 25)
        sns.heatmap(self._dataClass.part_f0dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        self.anim = animation.FuncAnimation(self.fig, func = self.animate, frames=None, save_count=0, interval=1, blit = False, repeat = False, cache_frame_data=False)

    def animate(self, i):
        plt.clf()
        print("???")
        plt.subplot(231)
        plt.title("dip2", fontsize = 25)    
        sns.heatmap(self._dataClass.part_f2dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(233)
        plt.title("dip1", fontsize = 25)
        sns.heatmap(self._dataClass.part_f1dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(235)
        plt.title("dip0", fontsize = 25)
        sns.heatmap(self._dataClass.part_f0dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        print("11")

class TacDataFetchClass(threading.Thread):
    def __init__(self, dataClass):
        threading.Thread.__init__(self)
        self._dataClass = dataClass
        rospy.init_node('Tac_listener', anonymous=True) 
        self.rate = rospy.Rate(50) # hz  

    def tac_callback(self, tac_data):
        self._dataClass.data = tac_data.states        
        tmp_f0dip = self._dataClass.data[1].data[::-1] # just for plotting; making f0 upside-down
        tmp_f1dip = self._dataClass.data[2].data
        tmp_f2dip = self._dataClass.data[3].data 
        
        self._dataClass.part_f0dip = np.reshape(tmp_f0dip, [12, 12])
        self._dataClass.part_f1dip = np.reshape(tmp_f1dip, [12, 12])
        self._dataClass.part_f2dip = np.reshape(tmp_f2dip, [12, 12])
        

    def run(self):
        print("updating data")
        rospy.Subscriber("/tactile_states", TrxTactileStates, self.tac_callback, queue_size=1)
        rospy.spin()
            


data = TacDataClass()
plotter1 = TacPlotClass_dip(data)
fetcher = TacDataFetchClass(data)
fetcher.start()

plt.show()