#!/usr/bin/env python

from rospy.core import NullHandler
from limb_core_msgs.msg import JointCommand
from limb_core_msgs.msg import JointState
from std_msgs.msg import Header
import rospy
import numpy as np
from time import sleep
import time
from socket import *

pre_move1 = np.array([0, 0,-1.5,0.523,-0.523,1.5,0.523,-0.523])
pre_move2 = np.array([0,0,-1.047,0,0,1.047,0,0])
pre_move3 = np.array([1, 1, 0, 1, 1, 0, 1, 1])
pre_move4 = np.array([1, -0.623, -1.57, 0, 0, 1.57, 0, 0])
pre_move5 = np.array([1, -0.523, -1.57, 0, 0, 1.57, 0, 0])
pre_move6 = np.array([1, -0.423, -1.57, 0, 0, 1.57, 0, 0])
pre_move7 = np.array([1, -0.323, -1.57, 0, 0, 1.57, 0, 0])

tg1 = np.array([0,0,-1.5,0.823,-0.453,1.5,0.823,-0.453])
tg2 = np.array([1,-0.323,-1.047,1,-0.323,1.047,1,-0.323])   # 3 fins 60 deg
tg3 = np.array([1, 1.57, 0, 1, 1.57, 0, 1, 1.57])
tg4 = np.array([1, -0.623, -1.57, 0.823,-0.453, 1.57, 0.823,-0.453])
tg5 = np.array([1, -0.523, -1.57, 0.823,-0.453, 1.57, 0.823,-0.453])
tg6 = np.array([1, -0.423, -1.57, 0.823,-0.453, 1.57, 0.823,-0.453])
tg7 = np.array([1, -0.323, -1.57, 0.823,-0.453, 1.57, 0.823,-0.453])

step1 = 0.15
step2 = 0.1

def reset(pub, rate):
    for i in range(3):
        pub.publish(mode=1, command=np.array([0,0,0,0, 0,0,0,0]))
        rate.sleep()
    sleep(1)

def move(pub, rate, pre_move, tg, mode):
    step_num = 30
    
    for i in range(3):
        pub.publish(mode=1, command=pre_move)
        rate.sleep()
    print("Pre_pos OK")
    
    sleep(1)  
    for i in range(3):
        pub.publish(mode=1, command=tg)
        rate.sleep()
    print("Target_pos OK")
    
    # Countinue to input current
    sleep(1)
    print("Start to push ...")
    print("="*30)
    if mode == 1:  # Mode 1: Two fins push
        for i in range(30):
            joint_states = rospy.wait_for_message("/fpt_hand_left/joint_states", JointState)
            joint_pos = np.array(joint_states.position)
            joint_pos_next = joint_pos + np.array([0, 0, 0, 0.1, 0.1, 0, 0.1, 0.1])
            
            pub.publish(mode=1, command=joint_pos_next)
            rate.sleep()
            
    elif mode == 2:  # Mode 2: Three fins push
        for i in range(30):
            joint_states = rospy.wait_for_message("/fpt_hand_left/joint_states", JointState)
            joint_pos = np.array(joint_states.position)
            joint_pos_next = joint_pos + np.array([0, 0.1, 0, 0.1, 0.1, 0, 0.1, 0.1])
            
            pub.publish(mode=1, command=joint_pos_next)
            rate.sleep()



def main():
    pub = rospy.Publisher('/fpt_hand_left/controller', JointCommand, queue_size=10)
    rospy.init_node('tactile_controller', anonymous=True)
    rate = rospy.Rate(5) # hz
    reset(pub, rate)
    move(pub, rate, pre_move1, tg1, 1)  # Movement 1
    reset(pub, rate)
    move(pub, rate, pre_move2, tg2, 2)  # Movement 2
    reset(pub, rate)
    move(pub, rate, pre_move3, tg3, 2)  # Movement 3
    reset(pub, rate)
    move(pub, rate, pre_move4, tg4, 1)  # Movement 4
    move(pub, rate, pre_move5, tg5, 1)  # Movement 5
    move(pub, rate, pre_move6, tg6, 1)  # Movement 6
    move(pub, rate, pre_move7, tg7, 1)  # Movement 7
    reset(pub, rate)    

if __name__ == "__main__":
    try:
        main()
    except rospy.ROSInterruptException:
        pass