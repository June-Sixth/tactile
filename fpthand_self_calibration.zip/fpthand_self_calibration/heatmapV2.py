#!/usr/bin/env python3  

from perception_interface.msg import TactileMeasurement
import rospy
from datetime import datetime
from socket import *
import matplotlib as mpl
mpl.use('TkAgg')  # or whatever other backend that you want
import matplotlib.pyplot as plt
from matplotlib import animation
import numpy as np
import pathlib
import threading
import seaborn as sns


# plt.rcParams["figure.figsize"] = [30, 40]
plt.rcParams["figure.autolayout"] = True

this_file_dir = str(pathlib.Path(__file__).parent.absolute())
print("This file dir:", this_file_dir)


class TacDataClass():
    def __init__(self):
        self.data = np.empty(640)
        self.threshold = 50
        self.part_palm = np.ones([10, 10]) * -100
        self.part_f0mpp = np.ones([6, 6]) * -100
        self.part_f0dip = np.ones([12, 12]) * -100
        self.part_f1mpp = np.ones([6, 6]) * -100
        self.part_f1dip = np.ones([12, 12]) * -100
        self.part_f2mpp = np.ones([6, 6]) * -100
        self.part_f2dip = np.ones([12, 12]) * -100
        

class TacPlotClass_dip():    
    def __init__(self, dataClass):
        self._dataClass = dataClass
        self.fig = plt.figure(figsize=(30, 20))
        plt.subplot(231)
        plt.title("dip0", fontsize = 25)    
        sns.heatmap(self._dataClass.part_f1dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(233)
        plt.title("dip1", fontsize = 25)
        sns.heatmap(self._dataClass.part_f2dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(235)
        plt.title("dip2", fontsize = 25)
        sns.heatmap(self._dataClass.part_f0dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        self.anim = animation.FuncAnimation(self.fig, func = self.animate, frames=None, save_count=0, interval=1, blit = False, repeat = False, cache_frame_data=False)

    def animate(self, i):
        plt.clf()
        print("???")
        plt.subplot(231)
        plt.title("dip2", fontsize = 25)    
        sns.heatmap(self._dataClass.part_f1dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(233)
        plt.title("dip1", fontsize = 25)
        sns.heatmap(self._dataClass.part_f2dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(235)
        plt.title("dip0", fontsize = 25)
        sns.heatmap(self._dataClass.part_f0dip, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        print("11")

class TacPlotClass_mpp():    
    def __init__(self, dataClass):
        self._dataClass = dataClass
        self.fig = plt.figure(figsize=(15, 10))
        plt.subplot(231)
        plt.title("mpp2", fontsize = 25)    
        sns.heatmap(self._dataClass.part_f2mpp, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(233)
        plt.title("mpp1", fontsize = 25)
        sns.heatmap(self._dataClass.part_f1mpp, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(235)
        plt.title("mpp0", fontsize = 25)
        sns.heatmap(self._dataClass.part_f0mpp, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        self.anim = animation.FuncAnimation(self.fig, func = self.animate, frames=None, save_count=0, interval=1, blit = False, repeat = False, cache_frame_data=False)

    def animate(self, i):
        plt.clf()
        print("???")
        plt.subplot(231)
        plt.title("mpp2", fontsize = 25)    
        sns.heatmap(self._dataClass.part_f2mpp, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(233)
        plt.title("mpp1", fontsize = 25)
        sns.heatmap(self._dataClass.part_f1mpp, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        plt.subplot(235)
        plt.title("mpp0", fontsize = 25)
        sns.heatmap(self._dataClass.part_f0mpp, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        print("22")
    
    
class TacPlotClass_palm():    
    def __init__(self, dataClass):
        self._dataClass = dataClass
        self.fig = plt.figure(figsize=(12, 12))
        plt.title("palm", fontsize = 25)    
        sns.heatmap(self._dataClass.part_palm, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        self.anim = animation.FuncAnimation(self.fig, func = self.animate, frames=None, save_count=1, interval=1, blit = False, repeat = False, cache_frame_data=False)

    def animate(self, i):
        plt.clf()
        print("???")
        plt.title("palm", fontsize = 25)    
        sns.heatmap(self._dataClass.part_palm, vmin=-100, vmax=500, cbar=False, cbar_kws={}, cmap="YlGnBu", annot=True, annot_kws={"fontsize":12}, fmt='g', yticklabels=False, xticklabels=False, linewidths=.5)
        print("33")


class TacDataFetchClass(threading.Thread):
    def __init__(self, dataClass):
        threading.Thread.__init__(self)
        self._dataClass = dataClass
        rospy.init_node('Tac_listener', anonymous=True) 
        self.rate = rospy.Rate(50) # hz  

    def tac_callback(self, tac_data):
        self._dataClass.data = tac_data.data
        for i in range(10):
            self._dataClass.part_palm[i] = self._dataClass.data[i*10 : i*10+10]
        for i in range(6):
            self._dataClass.part_f2mpp[i] = self._dataClass.data[460 + i*6: 466 + i*6]
            self._dataClass.part_f1mpp[i] = self._dataClass.data[280 + i*6:286 + i*6]
            self._dataClass.part_f0mpp[-i] = (self._dataClass.data[100  + i*6:106 + i*6])[::-1]
        for i in range(12):
            # self._dataClass.part_f0dip[-i] = (self._dataClass.data[136 + i*12:148 + i*12])[::-1]
            # self._dataClass.part_f2dip[i] = self._dataClass.data[316 + i*12:328 + i*12]
            # self._dataClass.part_f1dip[i] = self._dataClass.data[496 + i*12:508 + i*12]
            self._dataClass.part_f1dip[i] = self._dataClass.data[136 + i*12:148 + i*12]
            self._dataClass.part_f2dip[i] = self._dataClass.data[316 + i*12:328 + i*12]
            self._dataClass.part_f0dip[-(i+1)] = (self._dataClass.data[496 + i*12:508 + i*12])[::-1]

    def run(self):
        print("updating data")
        rospy.Subscriber("/TactileMeasurements", TactileMeasurement, self.tac_callback, queue_size=1)
        rospy.spin()
            


data = TacDataClass()
plotter1 = TacPlotClass_dip(data)
# plotter2 = TacPlotClass_mpp(data)
# plotter3 = TacPlotClass_palm(data)
fetcher = TacDataFetchClass(data)
fetcher.start()

plt.show()